# Event Venue Booking & Catering Management System

A proposed web-based system for managing event venue bookings, hall availability, deposit invoices, and catering/vendor coordination.

## Project Overview

Event venues often manage bookings, deposits, and vendor tasks through paper registers, spreadsheets, phone calls, and messaging apps. These fragmented processes can cause booking conflicts, delayed deposit follow-ups, and missed preparation tasks.

This project proposes a centralized system to organize these workflows.

## Main Features (Proposed)

- **Hall Availability Calendar** — View hall availability and distinguish Available, Tentative, Confirmed, and Blocked time slots.
- **Booking Management** — Record client details, event type, date/time, hall, guest count, and special requirements.
- **Deposit Invoicing** — Create deposit invoices and track unpaid, partially paid, fully paid, and overdue invoices.
- **Payment Records** — Maintain a history of payments recorded against each invoice.
- **Vendor Management** — Store vendor details and service categories such as catering, decoration, photography, and audio-visual services.
- **Vendor Checklists** — Assign event preparation tasks and track Pending, In-Progress, and Completed items.
- **Dashboard and Reports** — Summarize upcoming events, pending deposits, and incomplete checklist items.
- **Role-Based Access** — Separate access for Administrators, Venue Managers, and Clients.

## Project Phases

### Phase I — Requirements Analysis & System Study
- Existing-system analysis and limitations
- Problem statement, objectives, and project scope
- Feasibility study
- Software Requirements Specification (SRS)
- Functional and non-functional requirements
- Use-case analysis

### Phase II — System Design
- Three-tier system architecture
- Module design
- Relational database design
- Data-flow and entity-relationship descriptions
- User-interface design
- Security design considerations

## Proposed Technology Stack

The report identifies the following possible technologies. The final stack has not yet been selected or implemented.

- **Frontend:** HTML, CSS, JavaScript; optionally React or Vue
- **Backend:** Node.js with Express, or Python with Django/Flask
- **Database:** MySQL or PostgreSQL
- **Development Tools:** Visual Studio Code, Git, and Postman

## Current Status

**Documentation and design phase (Phase I and Phase II).**

The accompanying report describes requirements and proposed system design. It does not claim that the application has been coded, tested, or deployed. Implementation, testing, and deployment are listed as future work.

## Repository Contents

- `README.md` — Project overview and documentation
- `docs/Project_Report.pdf` — Academic project report covering Phase I and Phase II

## Future Enhancements

- Implement the frontend, backend, and database
- Add automated booking-conflict validation
- Add invoice PDF generation and payment reminders
- Add client self-service booking and payment-status views
- Test the system and deploy it to a suitable hosting environment

## Author

**Manikandan A**  
Department of Computer Science and Engineering  
Project: Event Venue Booking & Catering Management System

## Note

This repository currently contains project documentation. Update this README as implementation progresses, and do not describe proposed features as completed until they have been developed and verified.
